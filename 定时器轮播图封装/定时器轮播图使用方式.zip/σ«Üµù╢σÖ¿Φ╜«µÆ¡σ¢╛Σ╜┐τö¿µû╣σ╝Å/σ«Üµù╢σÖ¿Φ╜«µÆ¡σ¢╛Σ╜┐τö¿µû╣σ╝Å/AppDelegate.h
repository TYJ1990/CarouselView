//
//  AppDelegate.h
//  定时器轮播图使用方式
//
//  Created by I三生有幸I on 16/5/27.
//  Copyright © 2016年 盛辰. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

