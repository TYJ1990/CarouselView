//
//  main.m
//  定时器轮播图使用方式
//
//  Created by I三生有幸I on 16/5/27.
//  Copyright © 2016年 盛辰. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
